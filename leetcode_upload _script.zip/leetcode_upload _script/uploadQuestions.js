import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import fs from "fs";

const client = new DynamoDBClient({
  region: "ap-south-1",
});

const docClient = DynamoDBDocumentClient.from(client);

const questions = JSON.parse(
  fs.readFileSync("./questions.json", "utf8")
);

async function uploadQuestions() {
  console.log(`Uploading ${questions.length} questions...\n`);

  for (const question of questions) {
    try {
      await docClient.send(
        new PutCommand({
          TableName: "LeetcodeQuestions",
          Item: question,
        })
      );

      console.log(`✅ Uploaded: ${question.title}`);
    } catch (err) {
      console.error(`❌ Failed: ${question.title}`);
      console.error(err.message);
    }
  }

  console.log("\n🎉 Upload Completed");
}

uploadQuestions();